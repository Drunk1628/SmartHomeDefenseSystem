CREATE TABLE security_alerts (
    id BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,

    device_id BIGINT,

    alert_type VARCHAR(50) NOT NULL,

    severity VARCHAR(20) NOT NULL
        CONSTRAINT security_alerts_severity_check
        CHECK (severity IN ('low', 'medium', 'high', 'critical')),

    description TEXT NOT NULL,

    alert_status VARCHAR(20) NOT NULL DEFAULT 'open'
        CONSTRAINT security_alerts_status_check
        CHECK (alert_status IN ('open', 'investigating', 'resolved')),

    detection_source VARCHAR(50) NOT NULL DEFAULT 'system',

    detected_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,

    resolved_at TIMESTAMPTZ,

    resolved_by BIGINT,

    CONSTRAINT fk_security_alerts_device
        FOREIGN KEY (device_id)
        REFERENCES devices(id)
        ON DELETE SET NULL,

    CONSTRAINT fk_security_alerts_resolved_by
        FOREIGN KEY (resolved_by)
        REFERENCES users(id)
        ON DELETE SET NULL,

    CONSTRAINT chk_security_alert_resolution
        CHECK (
            (alert_status = 'resolved' AND resolved_at IS NOT NULL)
            OR
            (alert_status <> 'resolved' AND resolved_at IS NULL)
        )
);

CREATE INDEX idx_security_alerts_status_time
    ON security_alerts (alert_status, detected_at DESC);

CREATE INDEX idx_security_alerts_severity
    ON security_alerts (severity);

CREATE INDEX idx_security_alerts_device_time
    ON security_alerts (device_id, detected_at DESC);

CREATE INDEX idx_security_alerts_source
    ON security_alerts (detection_source);

import { useEffect, useState, type FormEvent } from 'react';
import { UserPlus, Trash2 } from 'lucide-react';
import { enrollFace, getEnrolledPeople, removeEnrolledPerson, type EnrolledPerson } from '@/lib/face-recognition';

const MAX_IMAGE_BYTES = 5 * 1024 * 1024;
const SUPPORTED_TYPES = new Set(['image/jpeg', 'image/png', 'image/webp']);

export function FaceEnrollmentPanel({ demoMode }: { demoMode: boolean }) {
  const [name, setName] = useState('');
  const [image, setImage] = useState<File | null>(null);
  const [consentConfirmed, setConsentConfirmed] = useState(false);
  const [people, setPeople] = useState<EnrolledPerson[]>([]);
  const [busy, setBusy] = useState(false);
  const [message, setMessage] = useState('');
  const [error, setError] = useState('');
  const [refreshKey, setRefreshKey] = useState(0);

  useEffect(() => {
    if (demoMode) return;
    let cancelled = false;
    void getEnrolledPeople().then(items => {
      if (!cancelled) setPeople(items);
    }).catch(reason => {
      if (!cancelled) setError(reason instanceof Error ? reason.message : 'Could not load enrolled people.');
    });
    return () => { cancelled = true; };
  }, [demoMode, refreshKey]);

  const submitEnrollment = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    setError('');
    setMessage('');
    if (!name.trim()) { setError('Enter the person’s name.'); return; }
    if (!image) { setError('Choose a clear face photo.'); return; }
    if (!SUPPORTED_TYPES.has(image.type)) { setError('Choose a JPEG, PNG, or WebP image.'); return; }
    if (image.size > MAX_IMAGE_BYTES) { setError('The image must be 5 MB or smaller.'); return; }
    if (!consentConfirmed) { setError('Confirm that the person agreed to this enrollment.'); return; }

    setBusy(true);
    try {
      const result = await enrollFace(name.trim(), image, consentConfirmed);
      if (result.status === 'enrolled') {
        setMessage(`${result.identity} was enrolled. You can now try a recognition check.`);
        setName('');
        setImage(null);
        setConsentConfirmed(false);
        setRefreshKey(value => value + 1);
      } else if (result.status === 'no_face') {
        setError('No face was found. Choose a clear, front-facing photo.');
      } else if (result.status === 'multiple_faces') {
        setError('More than one face was found. Choose a photo with one person.');
      } else {
        setError('The service could not process this image. No person was enrolled.');
      }
    } catch (reason) {
      setError(reason instanceof Error ? reason.message : 'Enrollment could not be completed.');
    } finally {
      setBusy(false);
    }
  };

  const deletePerson = async (person: EnrolledPerson) => {
    setError('');
    setMessage('');
    try {
      await removeEnrolledPerson(person.name);
      setMessage(`${person.name} was removed from the authorized gallery.`);
      setRefreshKey(value => value + 1);
    } catch (reason) {
      setError(reason instanceof Error ? reason.message : 'Could not remove this person.');
    }
  };

  return (
    <section className="face-enrollment" aria-labelledby="face-enrollment-heading" data-testid="panel-face-enrollment">
      <div className="face-enrollment__heading">
        <div>
          <span className="face-enrollment__kicker">AUTHORIZED GALLERY</span>
          <h2 id="face-enrollment-heading">Enroll a person</h2>
          <p>Add a consenting person so their face can be compared during image review.</p>
        </div>
        <UserPlus size={20} aria-hidden="true" />
      </div>

      {demoMode ? (
        <p className="face-enrollment__notice">Connect the recognition service to enroll people. Demo mode does not save photos or face data.</p>
      ) : (
        <>
          <form className="face-enrollment__form" onSubmit={submitEnrollment}>
            <label htmlFor="face-enrollment-name">Person’s name</label>
            <input id="face-enrollment-name" type="text" maxLength={80} value={name} onChange={event => setName(event.target.value)} placeholder="e.g. Alex" autoComplete="off" />
            <label htmlFor="face-enrollment-image">Face photo</label>
            <input id="face-enrollment-image" type="file" accept="image/jpeg,image/png,image/webp" onChange={event => setImage(event.target.files?.[0] ?? null)} />
            {image && <span className="face-enrollment__file-name">Selected: {image.name}</span>}
            <label className="face-enrollment__consent">
              <input type="checkbox" checked={consentConfirmed} onChange={event => setConsentConfirmed(event.target.checked)} />
              <span>The person has agreed to use this photo for this face recognition project.</span>
            </label>
            <p className="face-enrollment__privacy">The service saves a face feature vector for matching; it does not keep the uploaded photo.</p>
            {error && <p className="face-enrollment__error" role="alert">{error}</p>}
            {message && <p className="face-enrollment__success" role="status">{message}</p>}
            <button className="face-enrollment__submit" type="submit" disabled={busy}>
              <UserPlus size={15} /> {busy ? 'Enrolling…' : 'Enroll person'}
            </button>
          </form>

          <div className="face-enrollment__people" aria-live="polite">
            <h3>Enrolled people</h3>
            {people.length === 0 ? <p>No people enrolled yet.</p> : people.map(person => (
              <div className="face-enrollment__person" key={person.name}>
                <span><strong>{person.name}</strong><small>{person.sample_count} photo sample{person.sample_count === 1 ? '' : 's'}</small></span>
                <button type="button" onClick={() => void deletePerson(person)} aria-label={`Remove ${person.name}`} title={`Remove ${person.name}`}><Trash2 size={15} /></button>
              </div>
            ))}
          </div>
        </>
      )}
    </section>
  );
}

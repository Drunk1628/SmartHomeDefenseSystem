import type { FaceRecognitionResult } from '@/components/face-recognition-page';

const recognitionEndpoint = import.meta.env.VITE_FACE_RECOGNITION_ENDPOINT?.trim() ?? '';
const enrollmentEndpoint = import.meta.env.VITE_FACE_ENROLL_ENDPOINT?.trim()
  ?? (recognitionEndpoint.endsWith('/api/recognize')
    ? recognitionEndpoint.replace(/\/api\/recognize$/, '/api/enroll')
    : '');

export const isFaceRecognitionDemoMode = recognitionEndpoint.length === 0;

export type EnrollmentResult = {
  status: 'enrolled' | 'no_face' | 'multiple_faces' | 'indeterminate';
  identity?: string;
  sample_count?: number;
};

export type EnrolledPerson = {
  name: string;
  sample_count: number;
  created_at: string;
};

type RecognitionStatus = FaceRecognitionResult['status'];

type BackendStatus = 'match' | 'no_match' | 'no_face' | 'multiple_faces' | 'indeterminate';

function normalizeStatus(value: unknown): RecognitionStatus | null {
  if (typeof value !== 'string') return null;
  const status = value.trim().toLowerCase() as BackendStatus;
  if (status === 'match') return 'authorized';
  if (status === 'no_match') return 'unauthorized';
  if (status === 'no_face' || status === 'multiple_faces' || status === 'indeterminate') {
    return 'unverified';
  }
  return null;
}

function resultReason(status: BackendStatus): string {
  const reasons: Record<BackendStatus, string> = {
    match: 'A match was found in the authorized demo gallery. This is not a door access decision.',
    no_match: 'No match was found in the authorized demo gallery. Do not grant entry based on this result alone.',
    no_face: 'No face was detected in the image, so it could not be compared.',
    multiple_faces: 'More than one face was detected. The image could not be safely matched.',
    indeterminate: 'The service could not complete the comparison. No identity decision was made.',
  };
  return reasons[status];
}

function readAsDataUrl(image: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onerror = () => reject(new Error('The selected image could not be read.'));
    reader.onload = () => {
      if (typeof reader.result === 'string') resolve(reader.result);
      else reject(new Error('The selected image could not be read.'));
    };
    reader.readAsDataURL(image);
  });
}

async function responseError(response: Response): Promise<Error> {
  try {
    const body = await response.json() as { detail?: unknown };
    if (typeof body.detail === 'string') return new Error(body.detail);
  } catch {
    // Fall back to the HTTP status when the server did not return JSON.
  }
  return new Error(`The enrollment service returned HTTP ${response.status}.`);
}

export async function enrollFace(name: string, image: File, consentConfirmed: boolean): Promise<EnrollmentResult> {
  if (!enrollmentEndpoint) throw new Error('The enrollment service is not configured.');
  const imageBase64 = await readAsDataUrl(image);
  const response = await fetch(enrollmentEndpoint, {
    method: 'POST',
    headers: { Accept: 'application/json', 'Content-Type': 'application/json' },
    body: JSON.stringify({ name, image_base64: imageBase64, consent_confirmed: consentConfirmed }),
    credentials: 'same-origin',
  });
  if (!response.ok) throw await responseError(response);
  const body = await response.json() as EnrollmentResult;
  if (!['enrolled', 'no_face', 'multiple_faces', 'indeterminate'].includes(body.status)) {
    throw new Error('The enrollment service returned an unexpected response.');
  }
  return body;
}

export async function getEnrolledPeople(): Promise<EnrolledPerson[]> {
  if (!enrollmentEndpoint) throw new Error('The enrollment service is not configured.');
  const endpoint = enrollmentEndpoint.replace(/\/api\/enroll$/, '/api/enrolled');
  const response = await fetch(endpoint, { headers: { Accept: 'application/json' }, credentials: 'same-origin' });
  if (!response.ok) throw await responseError(response);
  const body = await response.json() as { items?: unknown };
  if (!Array.isArray(body.items)) throw new Error('The enrollment service returned an unexpected people list.');
  return body.items as EnrolledPerson[];
}

export async function removeEnrolledPerson(name: string): Promise<void> {
  if (!enrollmentEndpoint) throw new Error('The enrollment service is not configured.');
  const endpoint = enrollmentEndpoint.replace(/\/api\/enroll$/, '/api/enrolled');
  const response = await fetch(`${endpoint}/${encodeURIComponent(name)}`, {
    method: 'DELETE',
    headers: { Accept: 'application/json' },
    credentials: 'same-origin',
  });
  if (!response.ok) throw await responseError(response);
}

function demoResult(status: RecognitionStatus): FaceRecognitionResult {
  const reasons: Record<RecognitionStatus, string> = {
    authorized: 'Demo outcome selected for interface preview only. No face match was performed and this is not an access decision.',
    unauthorized: 'Demo outcome selected for interface preview only. No face match was performed and this is not a real access detection.',
    unverified: 'No recognition service is connected. The image was not analysed, so the result cannot be verified.',
  };

  return {
    status,
    source: 'demo',
    reason: reasons[status],
    ...(status === 'authorized' ? { subjectLabel: 'Demo identity' } : {}),
  };
}

/**
 * Sends the selected image only when a face-recognition endpoint is explicitly configured.
 * Backend contract: POST JSON { image_base64: "data:image/...;base64,..." }.
 * Backend statuses are translated to the labels used by the review page.
 */
export async function recognizeFace(image: File, demoOutcome: RecognitionStatus): Promise<FaceRecognitionResult> {
  if (isFaceRecognitionDemoMode) {
    return demoResult(demoOutcome);
  }

  try {
    const imageBase64 = await readAsDataUrl(image);
    const response = await fetch(recognitionEndpoint, {
      method: 'POST',
      headers: { Accept: 'application/json', 'Content-Type': 'application/json' },
      body: JSON.stringify({ image_base64: imageBase64 }),
      credentials: 'same-origin',
    });

    if (!response.ok) {
      return {
        status: 'unverified',
        source: 'service',
        reason: `The recognition service returned an error (HTTP ${response.status}). No authorization decision was made.`,
      };
    }

    const payload: unknown = await response.json();
    if (!payload || typeof payload !== 'object' || Array.isArray(payload)) {
      return { status: 'unverified', source: 'service', reason: 'The recognition service returned an invalid response. No authorization decision was made.' };
    }

    const data = payload as Record<string, unknown>;
    const backendStatus = typeof data.status === 'string' ? data.status.trim().toLowerCase() as BackendStatus : null;
    const status = normalizeStatus(backendStatus);
    if (!backendStatus || !status) {
      return { status: 'unverified', source: 'service', reason: 'The recognition service response was not understood. No authorization decision was made.' };
    }
    const identity = typeof data.identity === 'string' ? data.identity.trim() : '';
    const providedSubjectLabel = typeof data.subjectLabel === 'string' ? data.subjectLabel.trim() : '';
    const subjectLabel = identity || providedSubjectLabel;

    return {
      status,
      source: 'service',
      reason: typeof data.reason === 'string' && data.reason.trim() ? data.reason.trim() : resultReason(backendStatus),
      ...(subjectLabel ? { subjectLabel } : {}),
    };
  } catch {
    return {
      status: 'unverified',
      source: 'service',
      reason: 'The recognition service could not be reached or its response could not be read. No authorization decision was made.',
    };
  }
}
